The files module for Python 3 handles all path and file manipulations, in
particular replacing os.path and some of os.

CONTACT:
Please send emails to Pavel Panchekha <pavpanchekha@gmail.com> about anything
to do with the files module.

INSTALLATION:
Run

   python setup.py install

to install the files module.
